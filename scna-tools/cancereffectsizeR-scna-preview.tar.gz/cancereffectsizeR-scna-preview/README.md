*Welcome to cancereffectsizeR!*

Please visit the visit the [package website](https://townsend-lab-yale.github.io/cancereffectsizeR/) for installation, tutorial, and documentation.

We welcome contributions and feedback. If you have questions or want to learn more about how to contribute to development, don't hesitate to open an issue or contact us.
